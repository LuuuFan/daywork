import React from 'react';

const StepListItem = ({step, removeStep}) => {
  // debugger
  return (
    <div className='step_list_item'>
      <li>
        <h3>{step.title}</h3>
        <p>{step.description}</p>
        <button onClick={ ()=> removeStep(step) } className="DeleteTodo">Delete</button>
      </li>
    </div>
  );
};

export default StepListItem;
