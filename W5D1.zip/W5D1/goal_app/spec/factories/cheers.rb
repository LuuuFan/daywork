FactoryBot.define do
  factory :cheer do
    user nil
    goal nil
  end
end
