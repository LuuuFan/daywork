FactoryBot.define do
  factory :user do
    username "MyString"
    password "password"
  end
end
