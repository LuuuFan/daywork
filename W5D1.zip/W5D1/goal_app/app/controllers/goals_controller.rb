class GoalsController < ApplicationController
  before_action :set_goal, only: [:show, :edit, :update, :destroy, :complete, :uncomplete]
  before_action :require_current_user
  # GET /goals
  # GET /goals.json
  # def index
  #   @goals = Goal.all
  # end

  # GET /goals/1
  # GET /goals/1.json
  def show
  end

  # GET /goals/new
  def new
    @goal = Goal.new
  end

  # GET /goals/1/edit
  # def edit
  # end

  # POST /goals
  # POST /goals.json
  def create
    @goal = Goal.new(goal_params)
    @goal.user_id = current_user.id
    if @goal.save
      redirect_to goal_url(@goal)
    else
      render :new
    end
  end

  def complete
    @goal.complete = true
    @goal.save
    redirect_to goal_url(@goal)
  end

  def uncomplete
    @goal.complete = false
    @goal.save
    redirect_to goal_url(@goal)
  end

  # PATCH/PUT /goals/1
  # PATCH/PUT /goals/1.json
  # def update
  #
  # end

  # DELETE /goals/1
  # DELETE /goals/1.json
  def destroy
      @goal.destroy
      redirect_to user_url(@goal.user)
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_goal
      @goal = Goal.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def goal_params
      params.require(:goal).permit(:title, :details, :private, :completed, :user_id)
    end
end
