class Goal < ApplicationRecord
  validates :title, :detail, :private, :completed, presence: true
  belongs_to :user
  
end
