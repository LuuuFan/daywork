require "application_system_test_case"

class CheersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit cheers_url
  #
  #   assert_selector "h1", text: "Cheer"
  # end
end
