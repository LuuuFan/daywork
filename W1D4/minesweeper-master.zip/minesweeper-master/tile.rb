

class Tile
  attr_reader :num, :reveal

  def initialize(num = 0)
    @num = num
    @reveal = false

  end

  def bombed?
    num == -2 ? true : false
  end

  def flagged?
    num == -1 ? true : false
  end

  def revealed?
    reveal
  end

  private

end
